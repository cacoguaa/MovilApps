package com.map.cacoguaa.medicamentoslegales;

public class Medicamento {
    private String atc;
    private String cantidad;
    private String descripcionatc;
    private String fechaactivo;
    private String viaadministracion;

    public Medicamento(String atc, String cantidad, String descripcionatc, String fechaactivo, String viaadministracion) {
        this.atc = atc;
        this.cantidad = cantidad;
        this.descripcionatc = descripcionatc;
        this.fechaactivo = fechaactivo;
        this.viaadministracion = viaadministracion;
    }

    public String getAtc() {
        return atc;
    }

    public void setAtc(String atc) {
        this.atc = atc;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getDescripcionatc() {
        return descripcionatc;
    }

    public void setDescripcionatc(String descripcionatc) {
        this.descripcionatc = descripcionatc;
    }

    public String getFechaactivo() {
        return fechaactivo;
    }

    public void setFechaactivo(String fechaactivo) {
        this.fechaactivo = fechaactivo;
    }

    public String getViaadministracion() {
        return viaadministracion;
    }

    public void setViaadministracion(String viaadministracion) {
        this.viaadministracion = viaadministracion;
    }

    public String toString(){
        return "Atc: " + getAtc()+ "\n" +
                "Descripción: " + getDescripcionatc() + "\n" +
                "Fecha Activo: " + getFechaactivo() + "\n" +
                "Cantidad: " + getCantidad() + "\n" +
                "Via Administración: " + getViaadministracion();
    }
}
