package com.map.cacoguaa.medicamentoslegales;

import android.app.ListActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends ListActivity {

    ArrayList<Medicamento> medicamentos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        makeRequest();
    }

    public void makeRequest(){
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="https://www.datos.gov.co/resource/wqeu-3uhz.json";

        medicamentos = new ArrayList<Medicamento>();

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            if(response.length() > 0){
                                for(int i = 0; i < response.length(); i++){
                                    JSONObject jsonObject = response.getJSONObject(i);
                                    medicamentos.add( new Medicamento(
                                            jsonObject.getString("atc"),
                                            jsonObject.getString("cantidad"),
                                            jsonObject.getString("descripcionatc"),
                                            jsonObject.getString("fechaactivo"),
                                            jsonObject.getString("fechaactivo"),
                                            jsonObject.getString("viaadministracion")
                                    ));
                                    updateView();
                                    VolleyLog.d(jsonObject.getString("atc"));
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("Tag", "Error" + error.getMessage());
                    }
                }
        );

        queue.add(jsonArrayRequest);
    }

    public void updateView(){

        VolleyLog.d("testvolle", "test");
        Log.d("testlog", "test");
        ArrayAdapter<Medicamento> adapter = new ArrayAdapter<Medicamento>(this,
                android.R.layout.simple_list_item_1, medicamentos);

        setListAdapter(adapter);
    }
}
